package com.example.employeerecord;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Employee {

    //attributes
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String email;
    private String role;
    private Long experience;
    private Long salary;

    //constructors
    protected Employee(){}

    public Employee(String fName, String lName, String phoneNumber, String email, String role, Long experience, Long salary) {
        this.firstName = fName;
        this.lastName = lName;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.role = role;
        this.experience = experience;
        this.salary = salary;
    }


    //getters
    public Long getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public String getRole() {
        return role;
    }

    public Long getExperience() {
        return experience;
    }

    public Long getSalary() {
        return salary;
    }


    //setters
    public void setId(Long id) {
        this.id = id;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setExperience(Long experience) {
        this.experience = experience;
    }

    public void setSalary(Long salary) {
        this.salary = salary;
    }

    //to string method
    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", email='" + email + '\'' +
                ", role='" + role + '\'' +
                ", experience=" + experience +
                ", salary=" + salary +
                '}';
    }
}
