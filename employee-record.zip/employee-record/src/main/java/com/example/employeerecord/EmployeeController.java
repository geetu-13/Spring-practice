package com.example.employeerecord;


import org.springframework.data.jpa.repository.Query;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class EmployeeController {
    private final EmployeeRepository repository;

    public EmployeeController(EmployeeRepository repository) {
        this.repository = repository;
    }

    //get employee
    @GetMapping("/employee")
    List<Employee> all(){
        return repository.findAll();
    }
    @GetMapping("/employee/{id}")
    Employee employeeById(@PathVariable Long id){
        return repository.findById(id).orElseThrow(()->new EmployeeNotFoundException(id));
    }
    @GetMapping("/employee/role/{role}")
    List<Employee> employeeByRole(@PathVariable String role){
        return repository.findByRole(role);
    }
    @GetMapping("/employee/name/{name}")
    List<Employee>employeeByName(@PathVariable String name){ return repository.findByFirstNameOrLastName(name, name); }
    @GetMapping("/employee/salary/{salary}")
    List<Employee> employeeBySalary(@PathVariable Long salary) { return repository.findBySalary(salary); }
    @GetMapping("/employee/salary/moreThan/{salary}")
    List<Employee>employeeByMoreSalary(@PathVariable Long salary){
        return repository.findBySalaryGreaterThan(salary);
    }
    @GetMapping("/employee/salary/lessThan/{salary}")
    List<Employee>employeeByLessSalary(@PathVariable Long salary) { return repository.findBySalaryLessThan(salary); }

    //add new employee
    @PostMapping("/employee")
    Employee addNewEmployee(@RequestBody Employee employee){
        return repository.save(employee);
    }

    //edit employee
    @PutMapping("/employee/{id}")
    Employee editExistingEmployee(@PathVariable Long id, @RequestBody Employee newEmployee){
        return repository.findById(id)
                .map(employee-> {
                            employee.setFirstName((newEmployee.getFirstName() != null) ? newEmployee.getFirstName() : employee.getFirstName());
                            employee.setLastName((newEmployee.getLastName()!=null)?newEmployee.getLastName():employee.getLastName());
                            employee.setEmail((newEmployee.getEmail()!=null)?newEmployee.getEmail():employee.getEmail());
                            employee.setExperience((newEmployee.getExperience()!=null)?newEmployee.getExperience():employee.getExperience());
                            employee.setRole((newEmployee.getRole()!=null)?newEmployee.getRole():employee.getRole());
                            employee.setSalary((newEmployee.getSalary()!=null)?newEmployee.getSalary():employee.getSalary());
                            employee.setPhoneNumber((newEmployee.getPhoneNumber()!=null)?newEmployee.getPhoneNumber():employee.getPhoneNumber());
                            return repository.save(employee);
                })
                .orElseGet(()->{
                    newEmployee.setId(id);
                    return repository.save(newEmployee);
                });
    }

    //delete employee
    @DeleteMapping("/employee/{id}")
    Employee deleteEmployee(@PathVariable Long id){
        return repository.findById(id).orElseThrow(()->new EmployeeNotFoundException(id));
    }

}
