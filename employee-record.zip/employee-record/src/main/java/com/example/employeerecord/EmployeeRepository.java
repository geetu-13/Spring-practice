package com.example.employeerecord;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    List<Employee> findByRole(String role);
    List<Employee> findBySalaryGreaterThan(Long salary);
    Employee findById(long id);
    List<Employee> findBySalaryLessThan(Long salary);
    List<Employee> findBySalary(Long salary);
    List<Employee> findByFirstNameOrLastName(String firstName,String lastName);

}
